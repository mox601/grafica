R e a d m e . t x t   f i l e   f o r   E x a m p l e . z i p
Copyright 1999 by Alexander Rohra. All rights reserved.


Description:

  The program, X29.exe, displays a model of the X29 aircraft (Copyright by
  Evans & Sutherland) that was converted from VRML to OpenGL using Vrml2OGL
  V1.01 (C) by Alexander Rohra.

  Note: This program was designed for a screen resolution of 800x600.
        Resolutions other than this, will cause the text at the bottom of
        the screen to be displayed improperly.


Archive contents:

  Besides this text file, the archive contains the executable X29.exe and
  the necessary source code files to reproduce it, except for GLUT.H and
  GLUT32.LIB, which are part of GLUT V3.7. Additionally the archive contains
  the original VRML file, X29.wrl.

  NOTE: Use pkunzip -d Example.zip or WinZip to uncompress it.


About the code:

  The code making up this program is standart OpenGL code mixed with version
  3.7 of the GLUT API. In order to compile it, create a Win32 Console
  Application project, insert the source code files supplied with this
  archive and link them with GLUT32.LIB (supplied with GLUT3.7).
  Under Windows95/98/NT you need to have GLUT32.DLL (part of the GLUT3.7
  package, it can also be found at
  http://www.tc.umn.edu/nlhome/g529/myra0002/gl/gl.html) and an OpenGL
  compatible grafic card to execute the program.


Credits:

  The X29 aircraft model is (C) by Evans & Sutherland (see X29.wrl).


Disclaimer and Distribution Notice:

  This program, X29.exe and its accompanying source files, are distributed
  in the hope that they will be useful, but WITHOUT ANY WARRANTY; without
  even the implied warranty of MERCHANTABILITY, COMPLETENESS or FITNESS FOR
  ANY PARTICULAR PURPOSE.

  The author, Alexander Rohra, accepts no responsibility for any loss or
  damage to any person(s) and/or hardware or software, as a result of using
  the program X29.exe or its source code.

  X29.exe is released into public domain as "FREEWARE" and may be freely
  copied as long as the disclaimer mentioned above is maintained in effect
  for any released versions. You may also use, modify and distribute the
  source code file, main.c. The model data contained in X29.wrl, X29OGL.c,
  X29Hdr.h and X29Dat.c is (C) by Evans & Sutherland and if unmodified,
  may be freely distributed as long as its copyright info is shown (see Info
  node in X29.wrl). For modifications to this data please refer to
  Evans & Sutherland for permission.



Download and Contact Information:

  Example.zip is part of the Vrml2OGL archive, V2OGL101.zip, which can be
  downloaded from http://www.geocities.com/SiliconValley/Program/3830 .

  For questions and/or comments please contact me at arohra@geocities.com.


Copyright 1999 by Alexander Rohra. All rights reserved.

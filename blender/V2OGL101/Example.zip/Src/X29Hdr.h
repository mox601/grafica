/*****************************************************************************
** X29Hdr.h - OpenGL C Code, File 2 of 3
**	Generated on Sun Aug 15 11:18:01 1999 from "X29.wrl" by
**	Vrml2OGL V1.01 Copyright 1999 by Alexander Rohra.
**	See X29OGL.c for more details.
**
** For disclaimer and distribution info please see ReadMe.txt (supplied with
** the archive containing this file).
*****************************************************************************/

#ifndef _X29HDR_H
#define _X29HDR_H

#include <GL\glut.h>

#define _CULL_FACE	GL_BACK
#define _MAT_FACE	GL_FRONT_AND_BACK

extern void DrawX29(void);

extern GLfloat ambMatX290000[];
extern GLfloat diffMatX290000[];
extern GLfloat specMatX290000[];
extern GLfloat emissMatX290000[];

#endif /* _X29HDR_H */

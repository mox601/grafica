/*
 *  texture.h
 *  
 *
 *  Created by Matteo on 28/09/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef TEXTURES_DEFINED
#define TEXTURES_DEFINED
#define TEXTURE_MOON 0
#define TEXTURE_WOOD 1
#endif

void loadTextures();
void setTexture(int texturename);

#!/bin/sh

simpleviewer mesh/dinosaur.ply
simpleviewer mesh/bunny.ply
simpleviewer mesh/armadillo.ply
simpleviewer mesh/maxplanck.ply
simpleviewer mesh/lucy.ply
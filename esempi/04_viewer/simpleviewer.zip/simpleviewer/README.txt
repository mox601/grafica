NOTA: leggere bene il Makefile per ricordarsi come
si fa un Makefile base in ambiente Unix

--------------------------------------------------------

Per compilare ed eseguire sotto Linux/Windows CygWin

	make 
	./run.sh
	
--------------------------------------------------------
	
Per compilare sotto windows Visual Studio

	Aprire il progetto visualstudio/simpleviewer.dsw
	Rebuild All
	Nel prompt MsDos eseguire .\run.bat
	
--------------------------------------------------------
	
Per compilare ed eseguire sotto MACOSX aggiungere
i framework OpenGL e Glut 
	
